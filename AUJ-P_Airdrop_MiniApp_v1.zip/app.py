import os
import asyncio
import threading
import time
import secrets
import logging
from datetime import datetime, timezone
from urllib.parse import quote

from flask import Flask, request, jsonify, send_from_directory
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo
from telegram.ext import Application, CommandHandler, ContextTypes
from telegram.error import TelegramError

logging.basicConfig(level=logging.INFO)
logging.getLogger("httpx").setLevel(logging.WARNING)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "data.json")

# Load locally saved key/value settings without requiring an extra dependency.
ENV_FILE = os.path.join(BASE_DIR, ".env")
if os.path.exists(ENV_FILE):
    try:
        with open(ENV_FILE, "r", encoding="utf-8") as _env_file:
            for _line in _env_file:
                _line = _line.strip()
                if _line and not _line.startswith("#") and "=" in _line:
                    _key, _value = _line.split("=", 1)
                    os.environ.setdefault(_key.strip(), _value.strip())
    except OSError:
        pass

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
BOT_USERNAME = os.getenv("BOT_USERNAME", "").strip().lstrip("@")
PUBLIC_URL = os.getenv("PUBLIC_URL", "").strip().rstrip("/")
CHANNEL_USERNAME = os.getenv("CHANNEL_USERNAME", "vibe_chaneell").strip().lstrip("@")
APP_TITLE = "AUJ-P"
# Deadline is initialized once on first run and then persisted.
DEFAULT_DURATION_SECONDS = 24 * 60 * 60

app = Flask(__name__, static_folder="static")
bot_app = None
bot_loop = None
bot_thread = None
data_lock = threading.RLock()


def load_data():
    import json
    if os.path.exists(DATA_FILE):
        try:
            with open(DATA_FILE, "r", encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            d = {}
    else:
        d = {}
    d.setdefault("users", {})
    d.setdefault("deadline", int(time.time()) + DEFAULT_DURATION_SECONDS)
    d.setdefault("started_at", int(time.time()))
    save_data(d)
    return d


def save_data(d):
    import json
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, DATA_FILE)


DATA = load_data()


def user_record(user_id):
    key = str(user_id)
    DATA["users"].setdefault(key, {
        "id": int(user_id),
        "first_name": "",
        "last_name": "",
        "username": "",
        "joined": False,
        "name_verified": False,
        "referrer": None,
        "referrals": [],
        "created_at": int(time.time())
    })
    return DATA["users"][key]


def miniapp_url(user_id, start_param=""):
    if not PUBLIC_URL:
        return "https://example.com"
    q = f"?uid={int(user_id)}"
    if start_param:
        q += "&start=" + quote(start_param)
    return PUBLIC_URL + "/" + q


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    u = update.effective_user
    if not u or not update.message:
        return
    with data_lock:
        rec = user_record(u.id)
        rec.update({
            "first_name": u.first_name or "",
            "last_name": u.last_name or "",
            "username": u.username or ""
        })
        payload = context.args[0] if context.args else ""
        if payload.startswith("ref_"):
            try:
                ref_id = int(payload[4:])
                if ref_id != u.id and str(ref_id) in DATA["users"] and not rec.get("referrer"):
                    rec["referrer"] = ref_id
            except ValueError:
                pass
        save_data(DATA)

    if not PUBLIC_URL:
        await update.message.reply_text(
            "ربات اجرا شد، اما هنوز PUBLIC_URL تنظیم نشده است.\n"
            "آدرس HTTPS سایت را در متغیر PUBLIC_URL قرار بده و ربات را دوباره اجرا کن."
        )
        return

    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("🚀 ورود به مینی‌اپ AUJ-P", web_app=WebAppInfo(url=miniapp_url(u.id, payload)))
    ]])
    await update.message.reply_text(
        "🎁 به ایردراپ AUJ-P خوش اومدی!\n\n"
        "برای بررسی عضویت کانال و تأیید نام، دکمه زیر رو بزن.",
        reply_markup=keyboard
    )


def get_bot_loop():
    global bot_loop
    if bot_loop is None:
        raise RuntimeError("Bot is not running")
    return bot_loop


async def telegram_check_member(user_id):
    if not bot_app or not bot_app.bot:
        return False
    try:
        member = await bot_app.bot.get_chat_member(chat_id="@" + CHANNEL_USERNAME, user_id=int(user_id))
        return member.status in ("creator", "administrator", "member")
    except TelegramError as e:
        logging.warning("get_chat_member failed: %s", e)
        return False


def run_async(coro, timeout=12):
    loop = get_bot_loop()
    fut = asyncio.run_coroutine_threadsafe(coro, loop)
    return fut.result(timeout=timeout)


def valid_telegram_init_data(init_data):
    """Validate Telegram WebApp initData using the bot token. Never trust uid from query alone."""
    if not BOT_TOKEN or not init_data:
        return None
    import hashlib
    import hmac
    from urllib.parse import parse_qsl
    try:
        pairs = dict(parse_qsl(init_data, keep_blank_values=True))
        received_hash = pairs.pop("hash", None)
        if not received_hash:
            return None
        data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret_key = hmac.new(b"WebAppData", BOT_TOKEN.encode(), hashlib.sha256).digest()
        calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(calculated, received_hash):
            return None
        import json
        user = json.loads(pairs.get("user", "{}"))
        auth_date = int(pairs.get("auth_date", "0"))
        if not user.get("id") or time.time() - auth_date > 86400:
            return None
        return user
    except Exception:
        return None


def resolve_user():
    # Production requests must include authentic Telegram WebApp initData.
    init_data = request.headers.get("X-Telegram-Init-Data", "") or request.form.get("initData", "")
    tg_user = valid_telegram_init_data(init_data)
    if tg_user:
        return tg_user
    # Local preview only. Disable this on public hosting.
    if os.getenv("ALLOW_DEV_UID", "0") == "1":
        uid = request.args.get("uid") or request.form.get("uid")
        if uid and uid.isdigit():
            with data_lock:
                rec = user_record(int(uid))
                return {"id": int(uid), "first_name": rec.get("first_name", ""), "last_name": rec.get("last_name", ""), "username": rec.get("username", "")}
    return None


@app.get("/")
def index():
    return send_from_directory("static", "index.html")


@app.get("/<path:path>")
def static_files(path):
    if path.startswith("api/"):
        return jsonify({"error": "not found"}), 404
    return send_from_directory("static", path)


@app.get("/api/config")
def config():
    return jsonify({
        "channelUrl": "https://t.me/" + CHANNEL_USERNAME,
        "channelName": "@" + CHANNEL_USERNAME,
        "appName": APP_TITLE,
        "deadline": DATA.get("deadline", int(time.time()) + DEFAULT_DURATION_SECONDS),
        "botUsername": BOT_USERNAME
    })


@app.post("/api/status")
def status():
    tg = resolve_user()
    if not tg:
        return jsonify({"ok": False, "error": "لطفاً مینی‌اپ را از داخل ربات تلگرام باز کن."}), 401
    uid = int(tg["id"])
    with data_lock:
        rec = user_record(uid)
        rec.update({
            "first_name": tg.get("first_name", rec.get("first_name", "")),
            "last_name": tg.get("last_name", rec.get("last_name", "")),
            "username": tg.get("username", rec.get("username", ""))
        })
        save_data(DATA)
    try:
        is_member = run_async(telegram_check_member(uid))
    except Exception:
        is_member = False
    with data_lock:
        rec = user_record(uid)
        rec["joined"] = bool(is_member)
        save_data(DATA)
        display_name = (rec.get("first_name", "") + " " + rec.get("last_name", "")).strip()
        name_ok = "auj-p" in display_name.casefold()
        rec["name_verified"] = bool(name_ok)
        save_data(DATA)
        unlocked = bool(is_member and name_ok)
        referrals = len(rec.get("referrals", []))
        ref_link = f"https://t.me/{BOT_USERNAME}?start=ref_{uid}" if BOT_USERNAME else ""
        return jsonify({
            "ok": True,
            "joined": bool(is_member),
            "nameVerified": bool(name_ok),
            "unlocked": unlocked,
            "displayName": display_name,
            "referrals": referrals,
            "refLink": ref_link,
            "deadline": DATA.get("deadline", int(time.time()) + DEFAULT_DURATION_SECONDS),
            "message": "دسترسی فعال است." if unlocked else ("برای ادامه باید عضو کانال شوی." if not is_member else "عبارت AUJ-P در نام نمایشی تلگرامت پیدا نشد.")
        })


@app.post("/api/verify-join")
def verify_join():
    tg = resolve_user()
    if not tg:
        return jsonify({"ok": False, "error": "مینی‌اپ را از داخل تلگرام باز کن."}), 401
    uid = int(tg["id"])
    try:
        is_member = run_async(telegram_check_member(uid))
    except Exception:
        is_member = False
    with data_lock:
        rec = user_record(uid)
        rec["joined"] = bool(is_member)
        save_data(DATA)
    return jsonify({"ok": True, "joined": bool(is_member), "message": "عضویت تأیید شد." if is_member else "هنوز عضو کانال نیستی؛ اول جوین شو و دوباره بررسی کن."})


@app.post("/api/verify-name")
def verify_name():
    tg = resolve_user()
    if not tg:
        return jsonify({"ok": False, "error": "مینی‌اپ را از داخل تلگرام باز کن."}), 401
    uid = int(tg["id"])
    with data_lock:
        rec = user_record(uid)
        first = tg.get("first_name", rec.get("first_name", "")) or ""
        last = tg.get("last_name", rec.get("last_name", "")) or ""
        display = (first + " " + last).strip()
        ok = "auj-p" in display.casefold()
        rec.update({"first_name": first, "last_name": last, "name_verified": ok})
        save_data(DATA)
        return jsonify({"ok": True, "nameVerified": ok, "displayName": display, "message": "نام تأیید شد." if ok else "عبارت AUJ-P هنوز در نام نمایشی تلگرامت نیست. نام را تغییر بده و دوباره بررسی کن."})


@app.post("/api/referral")
def referral():
    tg = resolve_user()
    if not tg:
        return jsonify({"ok": False, "error": "مینی‌اپ را از داخل تلگرام باز کن."}), 401
    uid = int(tg["id"])
    with data_lock:
        rec = user_record(uid)
        referrer = rec.get("referrer")
        if not referrer or str(referrer) not in DATA["users"] or referrer == uid:
            return jsonify({"ok": True, "credited": False, "message": "این حساب با لینک دعوت ثبت نشده است."})
        if not (rec.get("joined") and rec.get("name_verified")):
            return jsonify({"ok": True, "credited": False, "message": "برای ثبت دعوت، کاربر باید هر دو مرحله را کامل کند."})
        parent = user_record(referrer)
        if uid not in parent["referrals"]:
            parent["referrals"].append(uid)
            save_data(DATA)
            return jsonify({"ok": True, "credited": True, "message": "دعوت با موفقیت ثبت شد."})
        return jsonify({"ok": True, "credited": False, "message": "این دعوت قبلاً ثبت شده است."})


def bot_worker():
    global bot_app, bot_loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    bot_loop = loop
    bot_app = Application.builder().token(BOT_TOKEN).build()
    bot_app.add_handler(CommandHandler("start", start))
    async def runner():
        await bot_app.initialize()
        await bot_app.start()
        await bot_app.updater.start_polling(drop_pending_updates=False)
        logging.info("Telegram bot polling started")
        while True:
            await asyncio.sleep(3600)
    try:
        loop.run_until_complete(runner())
    except Exception:
        logging.exception("Bot loop stopped")


def main():
    global bot_thread
    if not BOT_TOKEN:
        token = input("توکن ربات تلگرام را از BotFather وارد کن: ").strip()
        if not token:
            print("توکن وارد نشد؛ خروج.")
            return
        # Keep it in this shell session and persist privately for next run.
        os.environ["BOT_TOKEN"] = token
        with open(".env", "w", encoding="utf-8") as f:
            f.write("BOT_TOKEN=" + token + "\n")
        print("توکن در فایل .env ذخیره شد. این فایل را عمومی نکن.")
        # module constant used by initData validation
        globals()["BOT_TOKEN"] = token

    if not PUBLIC_URL:
        public_url = input("آدرس عمومی HTTPS سایت/سرور (مثلاً https://your-domain.com): ").strip().rstrip("/")
        if public_url:
            os.environ["PUBLIC_URL"] = public_url
            globals()["PUBLIC_URL"] = public_url
    if not BOT_USERNAME:
        username = input("یوزرنیم ربات بدون @ (مثلاً AUJ_P_bot): ").strip().lstrip("@")
        if username:
            os.environ["BOT_USERNAME"] = username
            globals()["BOT_USERNAME"] = username

    bot_thread = threading.Thread(target=bot_worker, daemon=True)
    bot_thread.start()
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8080"))
    print(f"AUJ-P server listening on {host}:{port}")
    app.run(host=host, port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
