(() => {
  const tg = window.Telegram?.WebApp;
  if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor('#0b1020'); tg.setBackgroundColor('#0b1020'); } catch(e) {} }
  const $ = id => document.getElementById(id);
  let state = null, config = null, timerHandle = null;
  const initData = tg?.initData || '';
  async function api(path) {
    const res = await fetch(path, {method:'POST', headers:{'Content-Type':'application/json','X-Telegram-Init-Data':initData}, body:'{}'});
    let data = {}; try { data = await res.json(); } catch(e) {}
    if (!res.ok) throw new Error(data.error || 'خطا در ارتباط با سرور');
    return data;
  }
  function toast(msg) { $('toast').textContent = msg; setTimeout(() => { if ($('toast').textContent === msg) $('toast').textContent=''; }, 3500); }
  function setStateIcon(id, done) { const el=$(id); el.textContent=done?'✓':'●'; el.classList.toggle('done',!!done); }
  function showLock(s) {
    $('lockedView').classList.toggle('hidden', !!s.unlocked);
    $('airdropView').classList.toggle('hidden', !s.unlocked);
    setStateIcon('joinState', s.joined);
    setStateIcon('nameState', s.nameVerified);
    $('refCount').textContent = new Intl.NumberFormat('fa-IR').format(s.referrals || 0);
    if (s.refLink) $('inviteLinkText').textContent=s.refLink;
    if (s.unlocked) {
      api('/api/referral').then(r=>{ if(r.credited) toast(r.message); }).catch(()=>{});
      startCountdown(s.deadline || config.deadline);
    }
  }
  async function refresh() {
    try {
      state = await api('/api/status');
      showLock(state);
    } catch(e) {
      $('lockedView').classList.remove('hidden');
      $('airdropView').classList.add('hidden');
      document.querySelector('.intro').textContent = e.message || 'مینی‌اپ را از داخل ربات تلگرام باز کن.';
    }
  }
  $('checkJoin').addEventListener('click', async e => {
    const b=e.currentTarget; b.disabled=true; b.textContent='در حال بررسی...';
    try {
      const r=await api('/api/verify-join'); toast(r.message); await refresh();
    } catch(err) { toast(err.message); }
    b.disabled=false; b.textContent='بررسی عضویت من';
  });
  $('checkName').addEventListener('click', async e => {
    const b=e.currentTarget; b.disabled=true; b.textContent='در حال بررسی...';
    try {
      const r=await api('/api/verify-name'); toast(r.message); await refresh();
    } catch(err) { toast(err.message); }
    b.disabled=false; b.textContent='بررسی نام من';
  });
  async function copyLink() {
    const link=state?.refLink || '';
    if(!link) { toast('لینک دعوت آماده نیست.'); return; }
    try {
      if(navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(link);
      else { const ta=document.createElement('textarea'); ta.value=link; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
      toast('لینک دعوت کپی شد ✨');
      if(tg?.HapticFeedback) tg.HapticFeedback.notificationOccurred('success');
    } catch(e) { toast('کپی خودکار انجام نشد؛ لینک را لمس طولانی کن.'); }
  }
  $('copyBtn').addEventListener('click', copyLink);
  $('copyInvite').addEventListener('click', copyLink);
  function startCountdown(deadline) {
    if(timerHandle) clearInterval(timerHandle);
    const started = Number(config?.deadline || deadline) - 86400;
    function tick() {
      const now=Math.floor(Date.now()/1000), remaining=Math.max(0,Number(deadline)-now);
      const d=Math.floor(remaining/86400), h=Math.floor((remaining%86400)/3600), m=Math.floor((remaining%3600)/60), s=remaining%60;
      $('days').textContent=String(d).padStart(2,'0');
      $('hours').textContent=String(h).padStart(2,'0');
      $('minutes').textContent=String(m).padStart(2,'0');
      $('seconds').textContent=String(s).padStart(2,'0');
      const total=Math.max(1,Number(deadline)-started);
      $('timeProgress').style.width=(Math.max(0,Math.min(100,remaining/total*100)))+'%';
    }
    tick(); timerHandle=setInterval(tick,1000);
  }
  async function init() {
    try {
      config=await (await fetch('/api/config')).json();
      $('joinLink').href=config.channelUrl;
      await refresh();
    } catch(e) {
      document.querySelector('.intro').textContent='اتصال به سرور برقرار نشد. چند لحظه دیگر دوباره تلاش کن.';
    }
  }
  init();
  // Telegram may keep the mini app open after a user leaves the sponsor channel.
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
})();
